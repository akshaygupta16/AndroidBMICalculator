package com.example.hw01;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DecimalFormat;


public class MainActivity extends AppCompatActivity {


        private TextView tv_heading1;
        private TextView tv_weight1;
        private TextView tv_lb1;
        private TextView tv_height1;
        private TextView tv_ht_in1;
        private TextView tv_ht_ft1;
        private TextView tv_result1;
        private EditText et_weight1;
        private EditText et_ht_in1;
        private EditText et_ht_ft1;
        private Button bt_calc1;
        private View divider1;

//    private float user_ht_ft;
//    private float user_ht_in;


        @Override
        protected void onCreate (Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("BMI Calculator");

        tv_heading1 = findViewById(R.id.tv_heading);
        tv_weight1 = findViewById(R.id.tv_weight);
        tv_lb1 = findViewById(R.id.tv_lb);
        tv_height1 = findViewById(R.id.tv_height);
        tv_ht_ft1 = findViewById(R.id.tv_ht_ft);
        tv_ht_in1 = findViewById(R.id.tv_ht_in);
        tv_result1 = findViewById(R.id.tv_result);
        et_weight1 = findViewById(R.id.et_weight);
        et_ht_ft1 = findViewById(R.id.et_ht_ft);
        et_ht_in1 = findViewById(R.id.et_ht_in);
        bt_calc1 = findViewById(R.id.bt_calc);
        divider1 = findViewById(R.id.divider);


        bt_calc1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                float user_weight = 0;
                float user_ht_ft = 0;
                float user_ht_in = 0;

                String temp1 = et_weight1.getText().toString();
                String temp2 = et_ht_ft1.getText().toString();
                String temp3 = et_ht_in1.getText().toString();

                if (temp1 != null && !temp1.equals("")) {
                    user_weight = Float.valueOf(et_weight1.getText().toString());
                }
                if (et_weight1.getText().toString().equals("")) {
                    et_weight1.setError("Need a value");
                }


                if (temp2 != null && !temp2.equals("")) {
                    user_ht_ft = Float.valueOf(et_ht_ft1.getText().toString());
                }
                if (et_ht_ft1.getText().toString().equals("")) {
                    et_ht_ft1.setError("Need a value");
                }


                if (temp3 != null && !temp3.equals("")) {
                    user_ht_in = Float.valueOf(et_ht_in1.getText().toString());
                }
                if (et_ht_in1.getText().toString().equals("")) {
                    et_ht_in1.setError("Need a value");
                }


                float total_height = user_ht_in + user_ht_ft * 12;
                if (total_height == 0) {
                    Toast.makeText(MainActivity.this, "Height can not be Zero", Toast.LENGTH_SHORT).show();
                    clearall();

                }


                float bmi = (user_weight / (total_height * total_height)) * 703;

//                 float fbmi =
                String message = "";
                if (bmi < 18.5) {
                    message = "You are Underweight";
                }
                if (bmi >= 18.5 && bmi < 25) {
                    message = "Your weight is Normal";
                }
                if (bmi >= 25 && bmi < 30) {
                    message = "You are Overweight";
                }
                if (bmi >= 30) {
                    message = "You are obese";
                }
                DecimalFormat f = new DecimalFormat("##.00");

                if(total_height!=0) {
                    tv_result1.setText("Your BMI is : " + String.valueOf(f.format(bmi)) + "\n" + message);
                    Toast.makeText(MainActivity.this, "BMI Calculated!", Toast.LENGTH_SHORT).show();
                }

            }
        });

    }
        public void clearall () {
        et_ht_in1.setText("");
        et_ht_ft1.setText("");
        et_weight1.setText("");
    }
}

